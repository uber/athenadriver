select request_timestamp,elb_name from elb_logs limit 1
